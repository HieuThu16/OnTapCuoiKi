﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NTier.Common
{
   public enum LoadStatus
    {
       Initialized =1,
       Ghost = 2,
       Loaded= 3,
    }//end enum
}//end namespace
